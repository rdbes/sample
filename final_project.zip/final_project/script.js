document.addEventListener("DOMContentLoaded", () => {
  // 1. MOBILE MENU TOGGLE (Runs on all pages)
  const hamburger = document.getElementById("hamburger");
  const navLinks = document.getElementById("nav-links");

  if (hamburger && navLinks) {
    hamburger.addEventListener("click", () => {
      navLinks.classList.toggle("active");
      hamburger.classList.toggle("active");
    });
  }

  // 2. COUNTER ANIMATION (Home Page Only)
  const counters = document.querySelectorAll(".counter");

  if (counters.length > 0) {
    const speed = 200;

    const animateCounter = (counter) => {
      const updateCount = () => {
        const target = +counter.getAttribute("data-target");
        const count = +counter.innerText;
        const inc = target / speed;

        if (count < target) {
          counter.innerText = Math.ceil(count + inc);
          setTimeout(updateCount, 20);
        } else {
          counter.innerText = target + (target === 100 ? "%" : "+");
        }
      };
      updateCount();
    };

    const observer = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            animateCounter(entry.target);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.5 },
    );

    counters.forEach((counter) => observer.observe(counter));
  }

  // 3. GALLERY FILTER (Home Page Only)
  window.filterGallery = function (category) {
    const items = document.querySelectorAll(".gallery-item");
    const buttons = document.querySelectorAll(".filter-btn");

    if (items.length > 0) {
      buttons.forEach((btn) => {
        btn.classList.remove("active");
        if (
          btn.innerText
            .toLowerCase()
            .includes(category === "all" ? "all" : category)
        ) {
          btn.classList.add("active");
        }
      });

      items.forEach((item) => {
        if (category === "all") {
          item.classList.remove("hidden");
        } else {
          item.classList.contains(category)
            ? item.classList.remove("hidden")
            : item.classList.add("hidden");
        }
      });
    }
  };

  // 4. ACCORDION (About Page Only)
  const accordionHeaders = document.querySelectorAll(".accordion-header");

  if (accordionHeaders.length > 0) {
    accordionHeaders.forEach((header) => {
      header.addEventListener("click", () => {
        header.classList.toggle("active");
        const content = header.nextElementSibling;

        if (header.classList.contains("active")) {
          content.style.maxHeight = content.scrollHeight + "px";
        } else {
          content.style.maxHeight = 0;
        }
      });
    });
  }

  // 5. DARK MODE TOGGLE
  const themeToggle = document.getElementById("theme-toggle");
  const themeIcon = document.getElementById("theme-icon");

  const currentTheme = localStorage.getItem("theme");

  if (currentTheme) {
    document.documentElement.setAttribute("data-theme", currentTheme);

    if (currentTheme === "dark" && themeIcon) {
      themeIcon.src = "assets/sun.png";
    }
  }

  if (themeToggle && themeIcon) {
    themeToggle.addEventListener("click", () => {
      let theme = document.documentElement.getAttribute("data-theme");

      if (theme === "dark") {
        document.documentElement.setAttribute("data-theme", "light");
        localStorage.setItem("theme", "light");

        themeIcon.src = "assets/moon.png";
      } else {
        document.documentElement.setAttribute("data-theme", "dark");
        localStorage.setItem("theme", "dark");

        themeIcon.src = "assets/sun.png";
      }
    });
  }
});
